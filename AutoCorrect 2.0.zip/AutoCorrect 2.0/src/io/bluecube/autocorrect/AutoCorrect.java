package io.bluecube.autocorrect;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class AutoCorrect {

	private static List<String> words = new ArrayList<String>();
	
	public static void main(String[] args){	
		try(
				BufferedReader br = new BufferedReader(
						new InputStreamReader(AutoCorrect.class.getResourceAsStream("/words.txt")));
				Scanner s = new Scanner(System.in);
			) {
			
			String line;
			while((line = br.readLine()) != null){
				words.add(line);
			}
			
			while(true){
				if (s.hasNext()){
					String text = s.next();
					if (text.equalsIgnoreCase("exit")){
						break;
					}
					
					if (!words.contains(text)){
						System.out.println("Did you mean: " + autoCorrect(text) + "?");
					}else{
						System.out.println("You spelled " + text + " correctly :)");
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static String autoCorrect(String text){
		String closestMatch = "";
		int closestDistance = Integer.MAX_VALUE;
		for (String s : words){
			int distance = LevenshteinDistance.getDefaultInstance().apply(text, s);
			if (distance < closestDistance){
				closestDistance = distance;
				closestMatch = s;
			}
		}
		return closestMatch;
	}
}