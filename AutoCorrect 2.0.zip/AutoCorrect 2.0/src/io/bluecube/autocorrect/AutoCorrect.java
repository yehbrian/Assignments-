package io.bluecube.autocorrect;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * AutoCorrect Demo for Shared Services Catalog
 * 
 * @author Daniel Slutsky (dslutsky@ups.com, slutskda@vt.edu)
 * 
 */
public class AutoCorrect {

	private static List<String> words = new ArrayList<String>(); //word dictionary
	private static List<String> content = new ArrayList<String>(); //catalog service titles
	private static boolean running = true;
	private static boolean search = false;
	
	public static void main(String[] args){	
		Scanner s = new Scanner(System.in);
		
		loadFile("/words.txt", words);
		loadFile("/content.txt", content);

		System.out.println("\u001B[36m\u001B[1mAutoCorrect demonstration for Shared Services Catalog.");
		System.out.println();
		System.out.println("Enter any word...\u001B[0m");
		System.out.println();
			
		while(running){
			if (s.hasNext()){
				String text = s.nextLine().toLowerCase();
				if (text.startsWith("/")){
					parseCommand(text.split(" ")[0]); //use first index since commands are 1 word
				}else{
					if (!search){
						text = text.split(" ")[0];//first index since autocorrect only corrects 1 word at a time
						if (!words.contains(text)){
							System.out.print("\u001B[33m\u001B[1mDid you mean: " + autoCorrect(text) + "?");
						}else{
							System.out.print("\u001B[32m\u001B[1mYou spelled " + text + " correctly :)");
						}
						System.out.println("\u001B[0m");
					}else{
						search(text);
					}
				}
				System.out.println();
				System.out.println();
			}
		}
		s.close();
	}
	
	/**
	 * AutoCorrect the spelling of a given word
	 * 
	 * @param text The text to correct
	 * @return The corrected text
	 */
	private static String autoCorrect(String text){
		String closestMatch = "";
		int closestDistance = Integer.MAX_VALUE;
		for (String s : words){
			int distance = LevenshteinDistance.getDefaultInstance().apply(text, s);
			if (distance < closestDistance){
				closestDistance = distance;
				closestMatch = s;
			}
		}
		return closestMatch;
	}
	
	/**
	 * Parse commands
	 * 
	 * @param cmd The command
	 */
	private static void parseCommand(String cmd){
		switch(cmd.replace("/", "")){ //remove "/" from command
			case "exit":
				System.out.println("Demo stopped.");
				running = false;
				break;
			case "search":
				search = search ? false : true;
				break;
			default:
				System.out.println("\u001B[31mInvalid command.\u001B[0m");
				break;
		}
	}
	
	/**
	 * Read a file's contents into a given list
	 * 
	 * @param file The file to read
	 * @param list The list to put the data into
	 */
	private static void loadFile(String file, List<String> list){
		try (
				BufferedReader br = new BufferedReader(
				new InputStreamReader(AutoCorrect.class.getResourceAsStream(file)));
			){
			String line;
			while((line = br.readLine()) != null){
				list.add(line.toLowerCase());
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Search service catalog titles
	 * 
	 * @param text The service to search for
	 */
	private static void search(String text){
		String[] parts = text.split(" "); //Separate query by word
		boolean modified = false; //will use to see if a change was made to query
		for (int i = 0; i < parts.length; i++){
			String word = parts[i];
			if (!words.contains(word)){ //word spelled wrong?
				parts[i] = "\u001B[4m" + autoCorrect(word) + "\u001B[0m\u001B[35m"; //format & correct
				modified = true;
			}
		}
		
		StringBuilder sb = new StringBuilder();
		for (String s : parts){
			sb.append(s + " "); //reconstruct query
		}
		
		String query = sb.toString();
		System.out.println("\u001B[36m\u001B[1mShowing best results for: " + query + "\u001B[0m");

		if (modified){ //if corrected, give option to search for original query
			System.out.println("\u001B[33m\u001B[1mShow results for '" + text + "' instead?\u001B[0m");
		}
		
		Map<String, Integer> results = new HashMap<String, Integer>();
		query = query.replace("\u001B[4m", "").replace("\u001B[0m", "").replace("\u001B[35m", ""); //remove formatting
		//probably should use regex for ^, but whatever... too lazy and this works just fine
		for (String s : content){ //we'll only put results in the map that contain at least 1 query word
			int count = 0; 
			for (String str : query.split(" ")){
				if (s.contains(str)){
					count++;
				}
			}
			if (count > 0){
				results.put(s, LevenshteinDistance.getDefaultInstance().apply(query, s)); //put the word & distance
			}
		}
		
		SortedSet<Map.Entry<String, Integer>> sorted = sortByValues(results); //sort map by LevenshteinDistance
		int i = 0;
		for (Map.Entry<String, Integer> e : sorted){
			if (i < 10){ //print top 10 results... can be however many you want
				i++;
				System.out.println("-" + e.getKey());
			}else{
				break;
			}
		}
	}
	
	/**
	 * Courtesy of http://stackoverflow.com/questions/2864840/treemap-sort-by-value
	 * @param map Map to sort
	 * @return Map sorted by values
	 */
	private static <K,V extends Comparable<? super V>> SortedSet<Map.Entry<K,V>> sortByValues(Map<K,V> map) {
        SortedSet<Map.Entry<K,V>> sortedEntries = new TreeSet<Map.Entry<K,V>>(
            new Comparator<Map.Entry<K,V>>() {
                @Override public int compare(Map.Entry<K,V> e1, Map.Entry<K,V> e2) {
                    int res = e1.getValue().compareTo(e2.getValue());
                    return res != 0 ? res : 1;
                }
            }
        );
        sortedEntries.addAll(map.entrySet());
        return sortedEntries;
    }
}