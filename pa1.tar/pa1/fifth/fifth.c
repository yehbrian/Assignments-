#include <stdio.h>
#include <stdlib.h>
int hello = 0;
int columns =0;
int main(int argc, char *argv[]){

int first[1000][1000], second[1000][1000], sum[1000][1000];
      

  int m, n, c, d;
  if(argc!=2){
    printf("error\n");
    return 1;
  }
  FILE *input;
  input = fopen(argv[1], "r"); 
  if(input == NULL){
    printf("error\n");
    return 1;
  }
  int matrixsize1 = 0;
  int matrixsize2= 0;
  int num=0;
  int num2=0;
  char tmp;
  int count = 1;

  fscanf(input, "%d",&num);
  matrixsize1 = num;
  fscanf(input, "%d",&hello);
  columns = hello;
  fscanf(input,"%c", &tmp);

    
  for(c = 0; c<matrixsize1; c++){
    for(d = 0; d<columns; d++){
        fscanf(input, "%d", &num);
	first[c][d] = num;
    }
      fscanf(input, "%c", &tmp);
  }
 
  fscanf(input, "%c", &tmp);
 
   for(c = 0; c<matrixsize1; c++){
    for(d = 0; d<columns; d++){
        fscanf(input, "%d", &num);
	second[c][d] = num;
    }
      fscanf(input, "%c", &tmp);
  }

   for(c = 0; c<matrixsize1; c++){
   for(d = 0; d<columns; d++){
     sum[c][d] = first[c][d] + second[c][d];
     printf("%d\t", sum[c][d]);
    }
   printf("\n");
  }
   return 0;

  
}
