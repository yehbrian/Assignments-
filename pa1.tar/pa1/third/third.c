#include <stdio.h>
#include <stdlib.h>


struct node{
  int val;
  struct node*next;
};

typedef struct node node;

struct node *front;

struct node createNode(){
    struct node*newNode;
    newNode = (struct node*) malloc(sizeof(struct node));
    newNode->val = 0;
    newNode->next = NULL;
    return *newNode;
}

void print(node* front ){
  struct node *ptr = front;
  while(ptr !=NULL){
    printf("%d\t", ptr->val);
    ptr = ptr->next;
  }
  printf("\n");
}

node* insert(node* front, int value){
  node *search = front;
  while(search != NULL){
    if(search->val == value){
      return front;
    }
    search = search ->next;
  }

  node *new;
  node *temp;
  node *prev;
  new = (node *)malloc(sizeof(node));
  new-> val = value;
  new -> next = NULL;
  if(front == NULL){
    front = new;
    return front;
  }
  else if(value<front->val){
    new -> next = front;
    front = new;
    return front;
  }
  else{
    prev = front;
    temp = front->next;
    while(temp != NULL && value> temp->val){
      prev = temp;
      temp = temp->next;
    }

    if(temp == NULL){
      prev -> next = new;
    }
    else{
      new -> next= temp;
      prev->next = new;
    }
  }
  return front;

}

node* Delete(node* front, int value){
  node *delete;
  node *prev = front;

  if(front -> val == value){
    front = front->next;
    free(prev);
    return front;
  }
  if(prev != NULL){
    if(prev -> val == value){
      front = prev->next;
      free(prev);
      return front;
    }
    while(prev->next!= NULL){
      if(prev -> next -> val == value){
	delete = prev->next;
	prev -> next = prev -> next -> next;
	free(delete);
	return front;
      }
      prev = prev -> next;
    }
    return front;
  }
}


int main(int argc, char *argv[]){
  if(argc!=2){
    printf("error\n");
    exit(1);
  }
  FILE *input;
  input = fopen(argv[1], "r");
  if(input == NULL){
    printf("error\n");
    exit(1);
  }

  char action;
  int num;
  char tmp;
 
  do{
    fscanf(input,"%c", &action);
    fscanf(input, "%d", &num);
    fscanf(input, "%c", &tmp);
 
    if(feof(input)){
      break;
    }

    if(action == 'i'){
      front =  insert(front, num);
      continue;
    }
    if(action == 'd'){
     front =  Delete(front, num);
      continue;
    }
    else{
      printf("error\n");
      continue;
    }
  }while(!feof(input));
 


  print(front);
  return 0;

}
