#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[1]){
  if (argv[1] == NULL){
    printf("error\n");
    return 1;
  }
  int x = atoi(argv[1]);
  if(x%2 == 1){
    printf("odd\n");
    return 0;
  }
  else{
    printf("even\n");
    return 0;
  }
}
