#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

int buckets[1000]= {INT_MAX};
int hashed =0;
int toGet = 0;
int count =0;

void set(int key){
  int func = hash(key);
  if(buckets[func] == INT_MAX){
    buckets[func] = key;
  }
  else{
    while(1){
      if(buckets[func] == key){
	printf("duplicate\n");
	return;
      }
      if(hashed <1000){
	hashed = hashed + 1;
      }
      else{
	hashed = 1;
      }
      if(buckets[func] != INT_MAX){
	buckets[func] = key;
	printf("inserted\n");
	return;
      
      }
    }
  }
}

int hash(int key){
  hashed = key%1000;
  return hashed;
}

void get(int key){
  
  hashed = hash(key);
  while(count < 1000){
    count++;
    if(buckets[hashed] == key){
      printf("present\n");
      return;
    }
    else{
    hashed = hashed + 1;
    }
    if(hashed>1000){
      hashed = 1;
    }
  }
  if(count == 1000){
    printf("absent\n");
  }
  count =0;
}

int main(int argc, char *argv[]){
  if(argc!=2){
    printf("error\n");
    return 1;
  }
  FILE *input;
  input = fopen(argv[1], "r"); 
  if(input == NULL){
    printf("error\n");
    return 1;
  }
  char action;
  int num;
  char tmp;
   do{
    fscanf(input, "%c", &action);
    fscanf(input, "%d", &num);
    fscanf(input, "%c", &tmp);
    if(feof(input)){
      break;
    }
    if(action == 'i'){
      set(num);

      continue;
    }
    if(action == 's'){
      get(num);

      continue;
    }
    else{
      printf("error\n");
      continue;
    }
   }while(!feof(input));
  return 0;

}
