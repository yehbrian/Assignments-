#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[1]){
  if (argv[1] == NULL){
    printf("error\n");
    return 1;
  }
  int x = atoi(argv[1]);
  int i;
  if (x ==1 ){
    printf("no\n");
    return 0;
  }
  for(i = 2; i<x; i++){
    if(x%i == 0){
      printf("no\n");
      return 0;
    }
  }
  printf("yes\n");
  return 0;
}
