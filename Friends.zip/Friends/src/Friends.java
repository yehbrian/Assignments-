import java.util.*;
import java.io.*;

public class Friends {
	static BufferedReader br1;
	static Scanner reader = new Scanner(System.in);

	public static void main(String[] args) 
			throws FileNotFoundException, IOException{
		System.out.println("Please enter the name of the graph file:");
		String line = reader.next();
		Graph graph = new Graph(line);
		int option;
		do{
			option = getOption();
			if(option>4 || option <1){
				do{
					System.out.println("Please enter a number ONLY between 1 and 4");
					option = getOption();
				}while((option>4 || option <1));
			}
			if(option == 1){
				System.out.println("Shortest path");
				System.out.print("\tName of person who wants the intro: ");
				String source = reader.next();
				System.out.print("\tName of target who will be introduced to " + source + ": ");
				String target = reader.next();
				graph.shortestPath(source, target);
			}
			if(option == 2){
				System.out.println("Cliques");
				System.out.println("\tName of school for which cliques are to be found: ");
				br1 = new BufferedReader(new InputStreamReader(System.in));
				String finalChoice = br1.readLine();
				graph.cliques(finalChoice);		
			}
			if(option == 3){
				System.out.println("Connectors");
				graph.dfs();

			}
			if(option == 4)
				return;
		}while(true);
	}

	public static int getOption() throws IOException {
		int c1 = 1, c2 = 2, c3 = 3, c4 = 4;
		System.out.println();
		System.out.println("MENU:");
		System.out.println("Please pick a number below");
		System.out.println(c1 + ". shortestPath(): \t displays the shortest chain of people in the graph starting at the first and ending at the second.");
		System.out.println(c2 + ". cliques(): \t\t displays the subgraphs for each of the cliques.");
		System.out.println(c3 + ". connectors(): \t displays names of all people who are connectors in the graph.");
		System.out.println(c4 + ". QUIT");
		System.out.print("\tEnter choice # => ");
		return reader.nextInt();
	}
}