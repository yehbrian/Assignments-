import java.util.*;
import java.io.*;

public class Graph {

	class Vertex {
		String name;
		String school;
		ArrayList<Vertex> friends;
		int dfsindex;
		int prev;
		int index;
		Vertex(int index, String name, String school) {
			this.index = index;
			this.name = name;
			this.school = school;
			this.friends = new ArrayList<Vertex>();
			this.dfsindex = 0;
			this.prev = 0;

		}
	}

	Vertex[] adjLists;
	boolean[] visited;

	public Graph(String file) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(file));
		int number = Integer.parseInt(sc.nextLine());
		adjLists = new Vertex[number];
		visited = new boolean[adjLists.length];
		for (int v=0; v < adjLists.length; v++) {
			String userInput = sc.nextLine();
			int counter = userInput.indexOf('|');

			String name = userInput.substring(0, counter);
			Boolean isStudent = false;
			String school = "";
			if(userInput.charAt(counter + 1) == 'y') {
				isStudent = true;
				school = userInput.substring(counter + 3);
			}

			if(isStudent) {
				adjLists[v] = new Vertex(v, name, school);
			} else {
				adjLists[v] = new Vertex(v, name, null);
			}
		}

		while (sc.hasNext()) {
			String string = sc.nextLine();
			int counter = string.indexOf('|');

			int first = indexForName(string.substring(0, counter));
			int second = indexForName(string.substring(counter + 1));

			adjLists[first].friends.add(adjLists[second]);
			adjLists[second].friends.add(adjLists[first]);

		}
	}



	public int indexForName(String name) {
		for (int x=0; x < adjLists.length; x++) {
			if (adjLists[x].name.equals(name)) {
				return x;
			}
		}
		return -1;
	}

	public String nameForIndex(int index) {
		if(adjLists[index] != null) {
			return adjLists[index].name;
		}
		return null;
	}


	//shortest path
	public void shortestPath(String source, String target) {
		Vertex[] toTraverse = new Vertex[adjLists.length];
		HashMap<Graph.Vertex, Boolean> seen = new HashMap<Graph.Vertex, Boolean>();
		HashMap<Graph.Vertex, Graph.Vertex> before = new HashMap<Graph.Vertex, Graph.Vertex>();
		Queue<Graph.Vertex> queue = new LinkedList<Graph.Vertex>();
		for(int i = 0; i < adjLists.length; i++) {
			seen.put(adjLists[i], false);
		}
		seen.put(adjLists[indexForName(source)], true);
		queue.add(adjLists[indexForName(source)]);
		Vertex vertex = adjLists[indexForName(source)];
		while (!queue.isEmpty()) {
			vertex = queue.remove();
			if (vertex.equals(adjLists[indexForName(target)])) {
				break;
			} else {
				for (Vertex toQueue : vertex.friends) {
					if (seen.get(toQueue) == false) {
						queue.add(toQueue);
						seen.put(toQueue, true);
						before.put(toQueue,vertex);
					}
				}
			}

		}
		if (vertex.equals(adjLists[indexForName(target)])) {
			int x = 0;
			for (Vertex i = adjLists[indexForName(target)]; i!=null; i=before.get(i)) {
				toTraverse[x]=i;
				x++;
			}
			for (int k = toTraverse.length-1; k>=0; k--) {
				if (toTraverse[k]!=null) {
					System.out.print(toTraverse[k].name);
					if (k!=0) {
						System.out.print("--");
					} else {
						System.out.print("\n");
					}
				}
			}
		}
	}


	//cliques

	public void cliques(String school){
		int cliquenumber= 1;
		int count=0;
		//Vertex[] path = new Vertex[adjLists.length];
		for(int x = 0; x < adjLists.length; x++){
			visited[x] = true;
		}
		for(int x = 0; x < adjLists.length; x++){
			if(visited[x] == false){
				continue;
			}
			if(adjLists[x].school == null){
				continue;
			}
			else if(adjLists[x].school.equals(school) && visited[x]){
				System.out.println("Clique " + cliquenumber + ": ");
				cliquenumber++;
				visited[x] = false;
				System.out.print(adjLists[x].name + "|y|" + adjLists[x].school + "\n");
				recursion(school, adjLists[x]);

			}
		}
	}
	ArrayList<String> hi = new ArrayList<String>();
	public void recursion(String school, Vertex root){
		for(int x =0; x<root.friends.size(); x++){
			if(root.friends.get(x).school == null){
				continue;
			}
			if(root.friends.get(x).school.equals(school) && visited[indexForName(root.friends.get(x).name)]){
				System.out.print(root.friends.get(x).name + "|y|" + school + "\n");
				String temp = root.name + "|" + root.friends.get(x).name;
				visited[indexForName(root.friends.get(x).name)] = false;
				//recursion(school, adjLists[root.friends.get(x).index]);
				recursion(school, adjLists[indexForName(root.friends.get(x).name)]);
				
			}
		}
		for(int x = 0; x<hi.size(); x++){
			//System.out.println(hi.get(x));
		}
		//else continue;

		return;
	}

	//connectors
	ArrayList<String> connectors = new ArrayList<String>();
	public void dfs() {
		boolean[] seen = new boolean[adjLists.length];
		boolean[] find = new boolean[adjLists.length];
		for (int x=0; x < seen.length; x++) 
			seen[x] = false;
		for (int x=0; x < find.length; x++) 
			find[x] = true;
		for (int x=0; x < seen.length; x++) {
			if (!seen[x]) {
				dfs(x, seen, find, adjLists[x]);
			}
		}
		System.out.println(connectors);
	}
	String temp;
	private int dfs = 0;
	private void dfs(int i, boolean[] seen, boolean[] find, Vertex v) {
		temp = adjLists[i].name;
		seen[i] = true;
		dfs++;
		adjLists[i].dfsindex = dfs;
		adjLists[i].prev = dfs;
		for (Vertex search : adjLists[i].friends) {
			if (!seen[indexForName(search.name)]) {
				find[indexForName(search.name)] = true;
				dfs(indexForName(search.name), seen, find, adjLists[i]);
				if(adjLists[i].dfsindex > adjLists[indexForName(search.name)].prev)
					adjLists[i].prev = Math.min(adjLists[i].prev,adjLists[indexForName(search.name)].prev);
			}
			else {
				find[indexForName(search.name)] = false;
				adjLists[i].prev = Math.min(adjLists[i].prev,adjLists[indexForName(search.name)].dfsindex);
			}
			System.out.println(adjLists[i].name + " " + adjLists[i].dfsindex);
			if(adjLists[i].dfsindex != 1){
				if (!connectors.contains(adjLists[i].name) && adjLists[i].dfsindex <= adjLists[indexForName(search.name)].prev)
					connectors.add(adjLists[i].name);
			}
		}
	}
}