# What's Cookin'?
Ever stood in front of your fridge wondering what to make? Cookbooks are full of recipes with only descriptions and recipe websites overwhelm the user making the search for the perfect recipe even more difficult. Our solution: What's Cookin, an image centered recipe application that randomly selects recipes and displays them on an intuitive user-friendly card format.

